/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crawler;

/**
 *
 * @author rauf
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author rauf
 */
public class Consumer2 {

    public void Start() {
        Crawl();

    }

    private void Crawl() {
        String crawlUrl = this.getCrawlUrl();
        try {
//            List<String> empNames= new ArrayList<String>();
            Collection<String> empNames = new TreeSet<String>(Collator.getInstance());
            //-------------------------
            Document doc = Jsoup.connect(crawlUrl).userAgent("Google").get();
            Elements anchors = doc.select("p");

            //-----------------------
            String fileName = "C:\\Users\\rauf\\Documents\\WebCrawlerProject\\PlainExtractedText.txt";
            File file = new File(fileName);

            //Assume Default encoding
            FileWriter fileWritter = new FileWriter(file.getAbsoluteFile(),true);

            //Always Wrap FileWriter in BufferedWriter
            BufferedWriter bufferedWriter = new BufferedWriter(fileWritter);
            //Note Write() does not automatically append a new line character

            //Always close files
            //-------------------------
            for (Element e : anchors) {
                System.out.println(e.text());

                String[] splitString = e.text().split("[-|_|*|\\)|\\(|/|'|;|!|\"|.|?|:|,\\s]+");
//                String[] splitString = e.text().split(":-|/|'|[|)|;|!|\"|.|?|:|,\\s]+");
//                String[] splitString = e.text().replaceAll("^[,\\s]+", "").split("[,\\s]+");
//                String[] splitString = e.text().replaceAll("^[.|?|:|,\\s]+", "").split("[:|,\\s]+");
                System.out.println(Arrays.toString(splitString));
                System.out.println("End");

                for (String word : splitString) {
//                    System.out.println("Checking : "+word);
                    empNames.add(word.toLowerCase());

                }

                System.out.println("-------------------------------");

            }
//                           Collections.sort(empNames, Collator.getInstance(new Locale("sk")));

            for (String emp : empNames) {
                bufferedWriter.append(emp);
                bufferedWriter.newLine();

                System.out.println(emp);
            }
            System.out.println("Sorting");

            System.out.println(empNames);

            bufferedWriter.close();

        } catch (IOException ex) {
            Logger.getLogger(WebCrawler.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private String getCrawlUrl() {
        String url = null;
        for (int i = 0; i <= 24; i++) {
           url = "http://freeurdujokes.com/Roman-Urdu-Jokes?page="+i; 
        }
       
        return url;
    }

    private void fileWritting(String word) {
        //The Name of the file to open

    }

}

