package Crawler;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author rauf
 */
public class Consumer3 {

    ArrayList al = new ArrayList();
    ArrayList sublinks = new ArrayList();
    int num = 100;

    public void Start() throws IOException {

        CrawlLinks();

        System.out.println("Links are: " + al);

        System.out.println("--------------------------");
        Crawl();

    }

    private void Crawl() throws IOException {
        for (int i = 116; i <= 439; i++) {
//            if( ( i!=41)){
            String crawlUrl2 = (String) al.get(i);
            if (!al.get(i).equals("#Top")) {

                CrawlSubLinks(crawlUrl2);
                System.out.println("SubLinks are:  " + sublinks);
                System.out.println("<<<<<<<<<>>>>>>>>>>>");
                for (int j = 2; j <= num; j++) {
                    System.out.println("Just Checking: " + sublinks.get(j));
                    if (sublinks.get(j).equals("mailto: webmaster@urdupoetry.com")) {
                        System.out.println("Ha ha ha");
                        String eik = (String) sublinks.get(j);

                        num = sublinks.indexOf(eik) - 3;
                        System.out.println(" Value of J is : " + j);
//                    break;

                    } else {

                        String crawlUrl = "http://www.urdupoetry.com/" + (String) sublinks.get(j);

                        System.out.println("Links are :" + crawlUrl);

                        try {
//            List<String> empNames= new ArrayList<String>();
                            Collection<String> empNames = new TreeSet<String>(Collator.getInstance());
                            //-------------------------
                            Document doc = Jsoup.connect(crawlUrl).userAgent("Google").get();
                            Elements anchors = doc.select("pre");

                            //-----------------------
                            String fileName = "C:\\Users\\rauf\\Documents\\WebCrawlerProject\\Recipes.txt";
                            File file = new File(fileName);

                            //Assume Default encoding
                            FileWriter fileWritter = new FileWriter(file.getAbsoluteFile(), true);

                            //Always Wrap FileWriter in BufferedWriter
                            BufferedWriter bufferedWriter = new BufferedWriter(fileWritter);
                            //Note Write() does not automatically append a new line character

                            //Always close files
                            //-------------------------
                            for (Element e : anchors) {
                                bufferedWriter.append(e.text());
                                bufferedWriter.newLine();

                                System.out.println("-------------------------------");

                            }
//                        bufferedWriter.append("-----------------------------------------");

                            bufferedWriter.close();

                        } catch (IOException ex) {
                            Logger.getLogger(WebCrawler.class.getName()).log(Level.SEVERE, null, ex);
                        }
//    }
                    }
//                break;
                }
                sublinks.removeAll(sublinks);
                System.out.println("After Removing:  " + sublinks);
            }

        }

    }

    private void CrawlLinks() throws IOException {
        String crawlUrl = this.getCrawlUrl();
        Document doc = Jsoup.connect(crawlUrl).userAgent("Google").get();
        Elements anchors = doc.select("a");
        for (Element e : anchors) {
            al.add(e.attr("href"));
        }

    }

    private void CrawlSubLinks(String url) throws IOException {
        String crawlUrl = "http://www.urdupoetry.com/" + url;
        Document doc = Jsoup.connect(crawlUrl).userAgent("Google").get();
        Elements anchors = doc.select("a");
        for (Element e : anchors) {
            sublinks.add(e.attr("href"));
        }

    }

    private String getCrawlUrl() {
        String url = null;

        url = "http://www.urdupoetry.com/poetlist.html";

        return url;
    }

    private void fileWritting(String word) {
        //The Name of the file to open

    }

}
