/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crawler;

/**
 *
 * @author rauf
 */
import java.io.*;
import java.text.Collator;
import java.util.Collection;
import java.util.TreeSet;

public class Filitering {

    public static void main(String[] args) {

        // The name of the file to open.
        String fileNameSource = "C:\\Users\\rauf\\Documents\\WebCrawlerProject\\temp.txt";
        String fileNameDestination = "target.txt";

        // This will reference one line at a time
        String line = null;
        int i = 0, j = 0;

        try {

            Collection<String> empNames2 = new TreeSet<String>(Collator.getInstance());

            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fileNameSource);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while ((line = bufferedReader.readLine()) != null) {
                System.out.println("Checking:: " + line + "  Number :  " + i);
                empNames2.add(line);
                i = i + 1;
            }

            for (String emp1 : empNames2) {
                System.out.println(emp1 + "   ----Number After : " + j);
                j = j + 1;
            }
            //---------------
            File file1 = new File(fileNameDestination);

            //Assume Default encoding
            FileWriter fileWritter5 = new FileWriter(file1.getAbsoluteFile());
            BufferedWriter bufferedWriter4 = new BufferedWriter(fileWritter5);

            for (String emp3 : empNames2) {
                bufferedWriter4.write(emp3);
                bufferedWriter4.newLine();

                System.out.println("Writting: " + emp3);
            }

            // Always close files.
            bufferedReader.close();
            bufferedWriter4.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Unable to open file '" + fileNameSource + "'");
        } catch (IOException ex) {
            System.out.println("Error reading file '" + fileNameSource + "'");
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
}
