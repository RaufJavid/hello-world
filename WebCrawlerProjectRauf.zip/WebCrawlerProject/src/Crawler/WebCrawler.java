package Crawler;

import java.io.IOException;

/**
 *
 * @author rauf
 */
public class WebCrawler {

    public static void main(String[] args) throws IOException {

        new Consumer4().Start();
        //http://world136.com/recipes/beef/steak-recipes.html

    }

}
