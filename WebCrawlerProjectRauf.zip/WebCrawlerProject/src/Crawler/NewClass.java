/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crawler;

import java.util.Arrays;
import javax.swing.text.html.parser.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author rauf
 */
public class NewClass {
    public static void main(String[] args) throws Exception {
    String input = ",A,B,C,D, ,,,";
    String[] values = input.replaceAll("^[,\\s]+", "").split("[,\\s]+");
    System.out.println(Arrays.toString(values));
    
    
        for (String element : values) {
            System.out.println(element);
           
            
        }
        System.out.println("RaufJavid");
}
    
}
